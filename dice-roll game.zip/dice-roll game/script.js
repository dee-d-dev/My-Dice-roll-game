

var scores, currentPlayer, roundScore, gameActive;
gameActive = true;
// var lastDiceRoll;
init();

document.querySelector('.btn-roll').addEventListener('click', function() {

    if (gameActive) {
            //Random number
            var dice1 = Math.floor(Math.random() * 6 ) + 1;
            var dice2 = Math.floor(Math.random() * 6 ) + 1;


            //Display  result
            document.getElementById('dice-1').style.display = 'block';
            document.getElementById('dice-2').style.display = 'block';

            document.getElementById('dice-1').src = 'img/dice-' + dice1 + '.png';
            document.getElementById('dice-2').src = 'img/dice-' + dice2 + '.png';


             if (dice1 !== 1 && dice2 !== 1) {
                //Add to the score
                roundScore += dice1 + dice2;
                document.querySelector("#current-" + currentPlayer).textContent = roundScore;
            } else {
                //Next player
                nextPlayer();
            }

            //Update round score but only IF the rolled number was not one
            /*if(lastDiceRoll === 6 && dice1, dice2  === 6) {
                scores[currentPlayer] = 0;
                document.querySelector('#score-' + currentPlayer).textContent = '0';
                nextPlayer();
            } else if (dice1 !== 1 && dice2 !==1) {
                //Add to the score
                roundScore += dice1 + dice2;
                document.querySelector("#current-" + currentPlayer).textContent = roundScore;
            } else {
                //Next player
                nextPlayer();
        }  

        lastDiceRoll = dice1, dice2;*/
    }

});

document.querySelector('.btn-hold').addEventListener('click', function() {
    if (gameActive) {
        //add CURRENT score to GLOBAL score
        scores[currentPlayer] += roundScore;

        //update UI
        document.querySelector('#score-' + currentPlayer).textContent = scores[currentPlayer];

        var input = document.querySelector('.final-score').value;
        var winningScore;

        if(input) {
            winningScore = input;
        } else {
            winningScore = 100;
        }
        
        document.querySelector('.dice').style.display = 'none';
    
        //check if player won the game
        if (scores[currentPlayer] >= winningScore) {
            document.querySelector('#name-' + currentPlayer).textContent = 'winner!';
            document.getElementById('dice-1').style.display = 'none';
            document.getElementById('dice-2').style.display = 'none';
            document.querySelector('.player-' + currentPlayer + '-panel' ).classList.add('winner');
            document.querySelector('.player-' + currentPlayer + '-panel' ).classList.remove('active');
            gameActive = false;
        } else {
            //next player
            nextPlayer();
        }
    }   
});

function nextPlayer() {
    currentPlayer === 0 ? currentPlayer = 1 : currentPlayer = 0;
    roundScore = 0;


    document.getElementById('current-0').textContent = '0';
    document.getElementById('current-1').textContent = '0';

    document.querySelector('.player-0-panel').classList.toggle('active');
    document.querySelector('.player-1-panel').classList.toggle('active');

    document.getElementById('dice-1').style.display = 'none';
    document.getElementById('dice-2').style.display = 'none';
};

document.querySelector('.btn-new').addEventListener('click', init);

function init() {
    scores = [0,0];
    currentPlayer = 0;
    roundScore = 0;
    gameActive = true;
    
    document.getElementById('score-0').textContent = '0';
    document.getElementById('score-1').textContent = '0';

    document.getElementById('current-0').textContent = '0';
    document.getElementById('current-1').textContent = '0';
    
    
    
    document.getElementById('dice-1').style.display = 'none';
    document.getElementById('dice-2').style.display = 'none';

    document.querySelector('.player-0-panel' ).classList.remove('winner');
    document.querySelector('.player-1-panel' ).classList.remove('winner');

    document.querySelector('.player-0-panel' ).classList.remove('active');
    document.querySelector('.player-1-panel' ).classList.remove('active');
    document.querySelector('.player-0-panel' ).classList.add('active');


    document.querySelector('#name-0').textContent = 'player 1';
    document.querySelector('#name-1').textContent = 'player 2';



};






















// var score = document.querySelector('#score-1').textContent;
// console.log(score);
// document.querySelector('#current-' + currentPlayer).textContent = dice;
//document.querySelector('#current-' + currentPlayer).innerHTML = "<em>" + dice + "</em>";